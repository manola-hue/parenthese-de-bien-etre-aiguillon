const toggle=document.querySelector('.menu-toggle'),nav=document.querySelector('.nav');
toggle?.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');toggle?.setAttribute('aria-expanded','false');}));
document.getElementById('year').textContent=new Date().getFullYear();
const form=document.getElementById('contactForm'),status=document.getElementById('formStatus');
form.addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('name').value.trim(),massage=document.getElementById('massage').value,message=document.getElementById('message').value.trim();const subject=encodeURIComponent(`Demande de rendez-vous — ${massage}`),body=encodeURIComponent(`Bonjour Manola,\n\nJe suis ${name}.\n\nMassage souhaité : ${massage}\nDurée : 1 heure\nTarif : 50 €\n\nMessage : ${message||'Pas de message supplémentaire.'}\n\nMerci !`);status.textContent='Ouverture de votre messagerie…';window.location.href=`mailto:lesmains.de.manola@gmail.com?subject=${subject}&body=${body}`;});
